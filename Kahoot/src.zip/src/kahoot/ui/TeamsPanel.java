package kahoot.ui;

public class TeamsPanel {
}
